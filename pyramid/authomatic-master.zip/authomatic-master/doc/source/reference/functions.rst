Functions
---------

.. seo-description::

	Reference of available functions.

.. automodule:: authomatic
   :members: provider_id, setup, login, access, async_access, credentials, request_elements, backend