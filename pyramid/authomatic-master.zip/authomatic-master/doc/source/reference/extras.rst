Extras
======

.. seo-description::

	There is extra stuff available for some frameworks and platforms in addition to adapters.

.. contents::
   :backlinks: none

.. automodule:: authomatic.extras.flask
   :members:

.. automodule:: authomatic.extras.gae
   :members:

.. automodule:: authomatic.extras.interfaces
   :members:

