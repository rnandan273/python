.. automodule:: authomatic.adapters

.. seo-description::
	
	Adapters enable Authomatic to work with any Python web framework.
	Currently there are adapters for Django, Webapp2, WebOb, Werkzeug and Flask.