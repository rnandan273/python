from authomatic import providers
from authomatic.exceptions import FailureError
import authomatic.core as core
import authomatic.settings as settings

class MozillaPersona(providers.AuthenticationProvider):
    pass
