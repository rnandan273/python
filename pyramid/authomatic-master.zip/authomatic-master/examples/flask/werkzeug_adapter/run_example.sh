#!/bin/sh

# Activate virtual environment.
. ../../../venv/bin/activate

# Start the Flask development server.
python main.py