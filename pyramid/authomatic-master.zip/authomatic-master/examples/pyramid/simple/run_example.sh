#!/bin/sh

# Activate virtual environment.
. ../../../venv/bin/activate

# Start the Pyramid development server.
python main.py