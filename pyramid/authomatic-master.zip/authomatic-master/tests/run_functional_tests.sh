#!/bin/sh
. ../venv/bin/activate
py.test functional_tests